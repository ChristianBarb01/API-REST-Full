package com.dbchristianbarbecho.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursoSpringbootApplication.class, args);
	}

}
