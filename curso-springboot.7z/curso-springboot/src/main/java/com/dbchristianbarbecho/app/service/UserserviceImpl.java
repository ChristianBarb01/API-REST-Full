package com.dbchristianbarbecho.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dbchristianbarbecho.app.entity.User;
import com.dbchristianbarbecho.app.repository.UserRepository;

@Service
public class UserserviceImpl implements UserService
{

	@Autowired
	private UserRepository userRepository;

	@Transactional(readOnly = true)
	public Iterable<User> findAll() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}
	@Transactional(readOnly = true)
	public Page<User> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return userRepository.findAll(pageable);
	}
	@Transactional(readOnly = true)
	public Optional<User> findById(Long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id);
	}
	@Transactional
	public User save(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}
	@Transactional
	public void deleteById(Long id) {
	userRepository.deleteById(id);
		
	}

}
