package com.dbchristianbarbecho.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dbchristianbarbecho.app.entity.User;

public interface UserRepository extends JpaRepository<User,Long> {

}
